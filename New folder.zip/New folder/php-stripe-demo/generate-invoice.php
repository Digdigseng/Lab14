<?php
require 'vendor/autoload.php'; // Include Composer autoloader

// Load environment variables from the .env file
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Set your Stripe secret key
$stripe = new \Stripe\StripeClient($_ENV['STRIPE_SECRET_KEY']);

// Fetch all customers and products
$customers = $stripe->customers->all(['limit' => 10]); // Fetch first 10 customers
$products = $stripe->products->all(); // Fetch all products

$message = ""; // To display success or error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Retrieve selected customer ID
        $customerId = $_POST['customer_id'];

        // Create a new invoice
        $invoice = $stripe->invoices->create([
            'customer' => $customerId,
        ]);

        // Add selected products as line items
        if (!empty($_POST['product_ids'])) {
            foreach ($_POST['product_ids'] as $productId) {
                $prices = $stripe->prices->all(['product' => $productId]);
                foreach ($prices->data as $price) {
                    if ($price->type === 'one_time') {
                        $stripe->invoiceItems->create([
                            'customer' => $customerId,
                            'price' => $price->id,
                            'invoice' => $invoice->id,
                        ]);
                    }
                }
            }
        }

        // Finalize the invoice
        $stripe->invoices->finalizeInvoice($invoice->id);

        // Retrieve the finalized invoice
        $invoice = $stripe->invoices->retrieve($invoice->id);

        // Display success message
        $message = "
            <div class='success'>
                <p>Invoice created successfully!</p>
                <p><a href='{$invoice->hosted_invoice_url}' target='_blank'>Pay Invoice</a></p>
                <p><a href='{$invoice->invoice_pdf}' target='_blank'>Download PDF</a></p>
            </div>
        ";
    } catch (\Stripe\Exception\ApiErrorException $e) {
        $message = "<div class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-container .success, .form-container .error {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-container .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .form-container .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-container select, .form-container input[type="checkbox"] {
            display: block;
            margin-bottom: 15px;
        }
        .form-container input[type="checkbox"] {
            display: inline-block;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Create Invoice</h1>
        <?php if (!empty($message)) echo $message; ?>
        <form method="POST" action="">
            <label for="customer">Select Customer:</label>
            <select name="customer_id" id="customer" required>
                <?php foreach ($customers->data as $customer): ?>
                    <option value="<?= htmlspecialchars($customer->id) ?>">
                        <?= htmlspecialchars($customer->name) ?: htmlspecialchars($customer->email) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Select Products:</label>
            <?php foreach ($products->data as $product): ?>
                <div>
                    <input type="checkbox" name="product_ids[]" value="<?= htmlspecialchars($product->id) ?>" id="product-<?= htmlspecialchars($product->id) ?>">
                    <label for="product-<?= htmlspecialchars($product->id) ?>"><?= htmlspecialchars($product->name) ?></label>
                </div>
            <?php endforeach; ?>

            <button type="submit">Generate Invoice</button>
        </form>
    </div>
</body>
</html>
