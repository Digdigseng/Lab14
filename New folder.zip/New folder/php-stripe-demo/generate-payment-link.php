<?php
require 'vendor/autoload.php'; // Include Composer autoloader

// Load environment variables from the .env file
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Set your Stripe API key
$stripe = new \Stripe\StripeClient($_ENV['STRIPE_SECRET_KEY']);

// Fetch all products
$products = $stripe->products->all();

$message = ""; // For success or error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Ensure at least one product is selected
        if (empty($_POST['product_ids'])) {
            throw new Exception("Please select at least one product.");
        }

        // Prepare line items for the payment link
        $lineItems = [];
        foreach ($_POST['product_ids'] as $productId) {
            // Fetch prices for the product
            $prices = $stripe->prices->all(['product' => $productId]);
            foreach ($prices->data as $price) {
                if ($price->type === 'one_time') {
                    $lineItems[] = [
                        'price' => $price->id,
                        'quantity' => 1,
                    ];
                }
            }
        }

        // Ensure line items are not empty (e.g., no valid prices found)
        if (empty($lineItems)) {
            throw new Exception("No valid prices found for the selected products.");
        }

        // Generate a payment link with the selected products
        $paymentLink = $stripe->paymentLinks->create([
            'line_items' => $lineItems,
        ]);

        // Store the payment link URL
        $paymentUrl = $paymentLink->url;

        $message = "<div class='success'>Payment link successfully created!<br>
                    <a href='{$paymentUrl}' target='_blank'>Pay Now</a></div>";
    } catch (\Stripe\Exception\ApiErrorException $e) {
        $message = "<div class='error'>Stripe Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    } catch (Exception $e) {
        $message = "<div class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

// Fetch successful payments
$payments = $stripe->paymentIntents->all(['limit' => 10]); // Fetch the last 10 payments
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Link Builder</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-container {
            background-color: #ffffff;
            padding: 20px;
            margin: 20px auto;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
        }
        .form-container h2 {
            margin-bottom: 15px;
            color: #555;
        }
        .form-container label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        .form-container input[type="checkbox"] {
            margin-right: 10px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: #ffffff;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <h1>Payment Link Builder</h1>
    <div class="form-container">
        <?php if (!empty($message)) echo $message; ?>
        <form method="POST" action="">
            <label>Select Products:</label>
            <?php foreach ($products->data as $product): ?>
                <div>
                    <input type="checkbox" name="product_ids[]" value="<?= htmlspecialchars($product->id) ?>">
                    <?= htmlspecialchars($product->name) ?>
                </div>
            <?php endforeach; ?>
            <br>
            <button type="submit">Generate Payment Link</button>
        </form>
    </div>

    <div class="form-container">
        <h2>Successful Payments</h2>
        <?php if (!empty($payments->data)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Payment Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments->data as $payment): ?>
                        <tr>
                            <td><?= htmlspecialchars($payment->id) ?></td>
                            <td><?= htmlspecialchars($payment->amount / 100) ?> <?= htmlspecialchars($payment->currency) ?></td>
                            <td><?= htmlspecialchars($payment->status) ?></td>
                            <td><?= date('Y-m-d H:i:s', $payment->created) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No successful payments found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
