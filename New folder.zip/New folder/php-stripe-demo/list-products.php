<?php
require_once 'vendor/autoload.php'; // Ensure Composer autoload is included
use Stripe\Stripe;

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Set your Stripe secret key from the .env file
Stripe::setApiKey($_ENV['STRIPE_SECRET_KEY']);

try {
    // Fetch products
    $products = \Stripe\Product::all(['limit' => 10]); // Adjust limit as needed
} catch (\Exception $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .product-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .product {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 20px;
            transition: transform 0.3s;
        }
        .product:hover {
            transform: translateY(-5px);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
        }
        .product img {
            max-width: 100%;
            height: auto;
            margin-bottom: 15px;
            border-radius: 10px;
        }
        .product h2 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #555;
        }
        .product p {
            font-size: 16px;
            color: #777;
        }
    </style>
</head>
<body>
    <h1>Product List</h1>
    <div class="product-container">
        <?php foreach ($products->data as $product): ?>
            <?php
            try {
                $priceData = \Stripe\Price::all(['product' => $product->id]);
                $priceDisplay = $priceData->data[0]->unit_amount / 100 . ' ' . strtoupper($priceData->data[0]->currency);
            } catch (\Exception $e) {
                $priceDisplay = "Price not available";
            }
            ?>
            <div class="product">
                <h2><?= htmlspecialchars($product->name) ?></h2>
                <img src="<?= htmlspecialchars($product->images[0] ?? 'https://via.placeholder.com/300') ?>" alt="<?= htmlspecialchars($product->name) ?>">
                <p>Price: <?= htmlspecialchars($priceDisplay) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
