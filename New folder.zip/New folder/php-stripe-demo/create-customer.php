<?php
require "init.php";

use Stripe\StripeClient;

// Check if form is submitted
$message = ""; // Initialize a message variable for feedback

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stripe = new StripeClient($_ENV['STRIPE_SECRET_KEY']);

        // Create customer in Stripe
        $customer = $stripe->customers->create([
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'address' => [
                'line1' => $_POST['address'],
            ],
            'phone' => $_POST['phone'],
        ]);

        $message = "<div class='success'>Customer created successfully!<br>Customer ID: " . htmlspecialchars($customer->id) . "</div>";
    } catch (Exception $e) {
        $message = "<div class='error'>Error creating customer:<br>" . htmlspecialchars($e->getMessage()) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-container .success, .form-container .error {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-container .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .form-container .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-container label {
            margin-bottom: 5px;
            font-weight: bold;
            display: block;
            color: #333;
        }
        .form-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .form-container button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Create Customer</h1>
        <?php if (!empty($message)) echo $message; ?>
        <form action="create-customer.php" method="POST">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="address">Address</label>
            <input type="text" id="address" name="address" required>

            <label for="phone">Phone</label>
            <input type="tel" id="phone" name="phone" required>

            <button type="submit">Create Customer</button>
        </form>
    </div>
</body>
</html>
